class C {
    doThing() {
        console.log("C.doThing");
    }
}
var c = new C();
c.doThing();
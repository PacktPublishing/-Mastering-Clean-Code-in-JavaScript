class B {
    doThing() {
        console.log("B.doThing");
    }
}
var b = new B();
b.doThing();
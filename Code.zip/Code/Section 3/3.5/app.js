require(["post-manager"], function(postManager) {
    postManager.printPosts();
})
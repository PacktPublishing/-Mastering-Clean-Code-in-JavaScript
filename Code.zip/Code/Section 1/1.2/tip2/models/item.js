export class Item {
    constructor(name, category, price) {

    }
}
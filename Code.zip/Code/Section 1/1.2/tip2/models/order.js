export class Order {
    constructor(id, customer, item) {
        this.customer = customer;
        this.item = item;
    }
}
//Train's departure time
//var time1 = new Date(2018, 1, 18);
var departureTime = new Date(2018, 1, 18);

//Train's arrival time
// var time2 = new Date(2018, 1, 29);
var arrivalTime = new Date(2018, 1, 29);

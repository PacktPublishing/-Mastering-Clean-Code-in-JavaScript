let person = {
    firstName: 'John',
    lastName: 'Smith',
    fatherName: 'Jake'
}

console.log("First name: " + person.firstName);

console.log("Father name: ", person.fatherName);


var customerOrderDetails = {
    customerId: 21,
    customerFirstName: 'John',
    customerLastName: 'Smith',
    sellerFirstName: 'Linda',
    sellerLastName = "James",
    totalPrice: 28.90
}

var cod = {
    cid: 21,
    cFName: 'John',
    cLName: 'Smith',
    sFName: 'Linda',
    sLName = "James",
    price: 28.90
}

export class Order {
    get() {
        //return order
    }
}

export class Customer {
    // getCustomer() {

    // }

    // get_customer() {

    // }

    get() {
        //follows the convention
    }
}
export class ErrorHandler {
    constructor(handler) {
        
    }
}